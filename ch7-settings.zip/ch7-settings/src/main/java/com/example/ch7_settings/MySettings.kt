package com.example.ch7_settings

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

//Fragment 클래스이다.. activity 가 출력해 줘야 한다..
class MySettings: PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        //아래의 한줄만으로도, 설정화면, 저장까지는 자동으로..
        setPreferencesFromResource(R.xml.settings, rootKey)

        //아래의 코드들은 필요하면.
        //key 로.. 설정 객체 획득..
        val idPreference: EditTextPreference? = findPreference("id")
        val colorPreference: ListPreference? = findPreference("color")

        //summary 를 동적으로 지정하고 싶다..
        //설정 값을 그대로 summary 에 지정하면 되는 경우에는..
        colorPreference?.summaryProvider = ListPreference.SimpleSummaryProvider.getInstance()
        //설정한 값을 이용해 summary 문자열을 알고리즘으로 만드는 경우..
        idPreference?.summaryProvider = Preference.SummaryProvider<EditTextPreference>{
            //유저 설정 값 획득..
            val id = it.text
            if(TextUtils.isEmpty(id)){
                "설정이 되지 않았습니다."//summary, 리턴 문자열.. 람다함수내에서는 return 사용 못한다.. 기본이
            }else {
                "설정한 ID 는 $id 입니다."
            }
        }

        idPreference?.setOnPreferenceChangeListener { preference, newValue ->
            Log.d("kkang", "key : ${preference.key}, value : $newValue")
            true
        }
    }
}