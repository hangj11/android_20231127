package com.example.ch15_retrofit

import com.google.gson.annotations.SerializedName

//클래스가 데이터를 표현하기 위한 VO, DTO, Entity 라면 과감하게.. data 예약어 추가..
data class User(
    var id: String,
    @SerializedName("first_name")
    var firstName: String,
    @SerializedName("last_name")
    var lastName: String,
    var avatar: String// 이미지 다운로드 url
)

data class UserList(
    var page: String,
    var data: List<User>?
)