package com.example.ch9_material

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.ch9_material.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //ViewPager 의 Adapter, 항목(화면)을 만들어 주는 역할..
    class MyFragmentAdapter(activity: FragmentActivity): FragmentStateAdapter(activity){
        //멤버 변수는 자동 초기화가 안된다..
        //선언과 동시에 초기값을 대입하던가..
        //nullable 로 선언하고 null을 대입하던가..
        //초기화를 미루고 싶으면 lateinit 으로 선언하던가..
        //생성자 초기화 블락인 init {} 에서 초기화 하던가..
        val fragments: List<Fragment>
        init {
            fragments = listOf(OneFragment(), TwoFragment(), ThreeFragment())
        }
        //항목 갯수를 판단하기 위해서 자동 호출..
        override fun getItemCount(): Int {
            return fragments.size
        }
        //항목을 구성하기 위해서 자동 호출.. 매개변수의 index 값을 보고 적절한 항목을 구성해서 리턴..
        override fun createFragment(position: Int): Fragment {
            return fragments[position]
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //ViewPager........................
        binding.viewPager.adapter = MyFragmentAdapter(this)
    }
}